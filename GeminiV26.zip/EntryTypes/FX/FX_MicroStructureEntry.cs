using System;
using cAlgo.API;
using GeminiV26.Core;
using GeminiV26.Core.Entry;
using GeminiV26.EntryTypes;
using GeminiV26.Instruments.FX;

namespace GeminiV26.EntryTypes.FX
{
    public sealed class FX_MicroStructureEntry : IEntryType
    {
        public EntryType Type => EntryType.FX_MicroStructure;

        private const double MinPullbackAtr = 0.15;

        public EntryEvaluation Evaluate(EntryContext ctx)
        {
            FxDirectionValidation.LogDirectionDebug(ctx);

            if (ctx == null || !ctx.IsReady || ctx.M5 == null || ctx.M5.Count < 30)
                return Invalid(ctx, TradeDirection.None, "CTX_NOT_READY", 0);

            if (ctx.LogicBias == TradeDirection.None)
                return Invalid(ctx, TradeDirection.None, "NO_LOGIC_BIAS", 0);

            if (ctx.AtrM5 <= 0)
                return Invalid(ctx, TradeDirection.None, "ATR_NOT_READY", 0);

            var fx = FxInstrumentMatrix.Get(ctx.Symbol);
            if (fx == null)
                return Invalid(ctx, TradeDirection.None, "NO_FX_PROFILE", 0);

            if (FxDirectionValidation.ShouldRejectLowConfidenceHtfConflict(ctx))
                return Invalid(ctx, TradeDirection.None, "FX_LOW_CONF_HTF_CONFLICT", 0);

            if (ctx.LogicBias == TradeDirection.Long)
            {
                var eval = EvalForDir(ctx, fx, TradeDirection.Long);
                EntryDirectionQuality.LogDecision(ctx, Type.ToString(), eval, null, eval.Direction);
                return EntryDecisionPolicy.Normalize(eval);
            }
            else if (ctx.LogicBias == TradeDirection.Short)
            {
                var eval = EvalForDir(ctx, fx, TradeDirection.Short);
                EntryDirectionQuality.LogDecision(ctx, Type.ToString(), null, eval, eval.Direction);
                return EntryDecisionPolicy.Normalize(eval);
            }

            return Invalid(ctx, TradeDirection.None, "NO_LOGIC_BIAS", 0);
        }

        private static EntryEvaluation EvalForDir(
            EntryContext ctx,
            dynamic fx,
            TradeDirection dir)
        {
            int score = 54;
            int setupScore = 0;
            double triggerScore = 0;

            ctx.Log?.Invoke(
                $"[FX_MICRO START] sym={ctx.Symbol} dir={dir} " +
                $"htf={ctx.FxHtfAllowedDirection}/{ctx.FxHtfConfidence01:F2} " +
                $"impulse={ctx.HasImpulse_M5} atrExp={ctx.IsAtrExpanding_M5} range={ctx.IsRange_M5}"
            );

            int barsSinceBreak =
                dir == TradeDirection.Long
                    ? ctx.BarsSinceHighBreak_M5
                    : ctx.BarsSinceLowBreak_M5;

            double pullbackDepthR =
                dir == TradeDirection.Long
                    ? ctx.PullbackDepthRLong_M5
                    : ctx.PullbackDepthRShort_M5;

            ctx.Log?.Invoke($"[FX_MICRO STRUCT] barsSinceBreak={barsSinceBreak}");

            // -----------------------------------------------------
            // MARKET STATE FILTER
            // -----------------------------------------------------
            if (ctx.MarketState != null && ctx.MarketState.IsLowVol)
                return Invalid(ctx, dir, "LOW_VOL_BLOCK", score);

            // -----------------------------------------------------
            // MICRO COMPRESSION DETECTION
            // -----------------------------------------------------
            if (!TryComputeCompression(ctx, 4, out double hi, out double lo, out double rAtr))
                return Invalid(ctx, dir, "COMPRESSION_FAIL", score);

            ctx.Log?.Invoke($"[FX_MICRO RANGE] dir={dir} rATR={rAtr:F2}");

            if (rAtr > 1.8)
                return Invalid(ctx, dir, "RANGE_TOO_WIDE", score);

            if (rAtr < 0.9) score += 4;
            else if (rAtr < 1.2) score += 2;
            else if (rAtr < 1.6) score += 0;

            // -----------------------------------------------------
            // IMPULSE CONTEXT
            // -----------------------------------------------------
            if (ctx.HasImpulse_M5)
                score += 3;
            else
                score -= 2;

            if (ctx.IsAtrExpanding_M5)
                score += 2;

            // -----------------------------------------------------
            // HTF ALIGNMENT (soft)
            // -----------------------------------------------------
            if (ctx.FxHtfAllowedDirection == dir)
            {
                score += 5;
            }
            else if (ctx.FxHtfAllowedDirection != TradeDirection.None)
            {
                score -= 10;
            }

            // -----------------------------------------------------
            // BREAKOUT TRIGGER
            // -----------------------------------------------------
            bool breakout = false;

            if (ctx.HasBreakout_M1 &&
                ctx.BreakoutDirection == dir &&
                rAtr < 1.6 &&
                barsSinceBreak <= 2)
            {
                breakout = true;
            }

            bool continuationSignal = breakout;

            bool hasStructure = pullbackDepthR >= MinPullbackAtr;

            if (!hasStructure)
                setupScore -= 35;
            else
                setupScore += 15;

            bool isRangeRegime = IsRangeOrSoftRangeRegime(ctx);
            bool hasNoCompression = rAtr > 1.2;
            bool hasWeakPullbackStructure = !hasStructure;
            var entryType = EntryType.FX_MicroStructure;

            bool isWeakFxMicro =
                entryType == EntryType.FX_MicroStructure &&
                ctx.LogicConfidence <= 45 &&
                isRangeRegime &&
                (hasNoCompression || hasWeakPullbackStructure);

            if (isWeakFxMicro)
            {
                string regimeLabel = ResolveRegimeLabel(ctx, isRangeRegime);
                ctx.Log?.Invoke(
                    $"[FX_MICRO_WEAK_FILTER] dir={dir} logicConf={ctx.LogicConfidence} regime={regimeLabel} noCompression={hasNoCompression.ToString().ToLowerInvariant()} weakPB={hasWeakPullbackStructure.ToString().ToLowerInvariant()} -> BLOCKED");
                return Invalid(ctx, dir, "FX_MICRO_WEAK_FILTER_BLOCK", score);
            }

            bool hasContinuation = continuationSignal;

            if (hasContinuation)
                setupScore += 20;

            score += 6;

            // -----------------------------------------------------
            // ENTRY BAR QUALITY
            // -----------------------------------------------------
            int lastClosed = ctx.M5.Count - 2;
            if (lastClosed < 0)
                return Invalid(ctx, dir, "NO_LAST_BAR", score);

            var last = ctx.M5[lastClosed];

            double body = Math.Abs(last.Close - last.Open);
            double range = last.High - last.Low;

            bool directionalBody =
                (dir == TradeDirection.Long && last.Close > last.Open) ||
                (dir == TradeDirection.Short && last.Close < last.Open);

            bool strongCandle =
                range > 0 &&
                directionalBody &&
                body / range > 0.55;

            bool followThrough = continuationSignal;

            if (strongCandle)
                score += 2;

            if (breakout)
                triggerScore += 1;

            if (strongCandle)
                triggerScore += 1;

            if (followThrough)
                triggerScore += 2;

            // -----------------------------------------------------
            // STRUCTURE FRESHNESS
            // -----------------------------------------------------
            if (barsSinceBreak > 3)
                score -= 3;

            if (barsSinceBreak > 5)
                return Invalid(ctx, dir, "LATE_STRUCTURE", score);

            // -----------------------------------------------------
            // ADX ENERGY CHECK
            // -----------------------------------------------------
            if (TryGetDouble(ctx, "Adx_M5", out var adx))
            {
                if (adx < 14)
                    score -= 6;

                if (adx > 28)
                    score += 2;
            }

            // -----------------------------------------------------
            // FINAL SCORE GATE
            // -----------------------------------------------------
            int minScore = EntryDecisionPolicy.MinScoreThreshold;

            score = ApplyMandatoryEntryAdjustments(ctx, dir, score, false);
            score += setupScore;
            score += (int)Math.Round(triggerScore * 5);

            if (triggerScore == 0)
                score -= 15;

            bool minimalTrigger = breakout || strongCandle;
            if (!minimalTrigger)
                score -= 10;

            bool triggerDominance =
                score >= minScore &&
                (
                    breakout ||
                    (strongCandle && ctx.HasImpulse_M5)
                );

            ctx.Log?.Invoke(
                $"[TRIGGER SCORE] breakout={(breakout ? 1 : 0)} strong={(strongCandle ? 1 : 0)} follow={(followThrough ? 1 : 0)} total={triggerScore:F0} finalScore={score}");

            if (setupScore <= -20 && !triggerDominance)
                score = Math.Min(score, minScore - 10);

            ctx.Log?.Invoke(
                $"[FX_MICRO FINAL] dir={dir} score={score} min={minScore} " +
                $"setupScore={setupScore} breakout={breakout} strong={strongCandle} " +
                $"follow={followThrough} triggerDominance={triggerDominance}");

            if (score < minScore)
                return Invalid(ctx, dir, $"LOW_SCORE {score}<{minScore}", score);

            return Valid(ctx, dir, score, rAtr, hi, lo);
        }

        private static bool TryComputeCompression(
            EntryContext ctx,
            int bars,
            out double hi,
            out double lo,
            out double rangeAtr)
        {
            hi = double.MinValue;
            lo = double.MaxValue;

            if (ctx.M5.Count < bars + 3)
            {
                rangeAtr = 0;
                return false;
            }

            int lastClosed = ctx.M5.Count - 2;
            int first = lastClosed - bars + 1;

            for (int i = first; i <= lastClosed; i++)
            {
                var bar = ctx.M5[i];
                hi = Math.Max(hi, bar.High);
                lo = Math.Min(lo, bar.Low);
            }

            rangeAtr = (hi - lo) / ctx.AtrM5;
            return hi > lo;
        }

        private static EntryEvaluation Valid(
            EntryContext ctx,
            TradeDirection dir,
            int score,
            double rAtr,
            double hi,
            double lo)
            => new EntryEvaluation
            {
                Symbol = ctx.Symbol,
                Type = EntryType.FX_MicroStructure,
                Direction = dir,
                Score = score,
                IsValid = true,
                Reason =
                    $"FX_MICRO score={score} rATR={rAtr:F2} hi={hi:F5} lo={lo:F5}"
            };

        private static EntryEvaluation Invalid(
            EntryContext ctx,
            TradeDirection dir,
            string reason,
            int score)
            => new EntryEvaluation
            {
                Symbol = ctx?.Symbol,
                Type = EntryType.FX_MicroStructure,
                Direction = dir,
                Score = score,
                IsValid = false,
                Reason = $"{reason} raw={score}"
            };

        private static bool TryGetDouble(object obj, string prop, out double value)
        {
            value = 0;
            if (obj == null) return false;

            var p = obj.GetType().GetProperty(prop);
            if (p == null) return false;

            var v = p.GetValue(obj);
            if (v == null) return false;

            try
            {
                value = Convert.ToDouble(v);
                return true;
            }
            catch
            {
                return false;
            }
        }

        private static int ApplyMandatoryEntryAdjustments(EntryContext ctx, TradeDirection direction, int score, bool applyTrendRegimePenalty)
        {
            return EntryDirectionQuality.Apply(
                ctx,
                direction,
                score,
                new DirectionQualityRequest
                {
                    TypeTag = "FX_MicroStructureEntry",
                    ApplyTrendRegimePenalty = applyTrendRegimePenalty
                });
        }

        private static bool IsRangeOrSoftRangeRegime(EntryContext ctx)
        {
            if (ctx == null)
                return false;

            if (ctx.IsRange_M5)
                return true;

            if (ctx.MarketState == null)
                return false;

            bool softRangeProxy =
                !ctx.MarketState.IsTrend &&
                (ctx.MarketState.IsLowVol || !ctx.IsAtrExpanding_M5);

            return ctx.MarketState.IsRange || softRangeProxy;
        }

        private static string ResolveRegimeLabel(EntryContext ctx, bool isRangeRegime)
        {
            if (!isRangeRegime)
                return "Trend";

            if (ctx?.MarketState != null && !ctx.MarketState.IsRange)
                return "SoftRange";

            return "Range";
        }
    }
}