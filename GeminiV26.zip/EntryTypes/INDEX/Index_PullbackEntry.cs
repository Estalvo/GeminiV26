﻿using GeminiV26.Core.Entry;
using GeminiV26.Core.Matrix;
using GeminiV26.Instruments.INDEX;
using System;

namespace GeminiV26.EntryTypes.INDEX
{
    public class Index_PullbackEntry : IEntryType
    {
        public EntryType Type => EntryType.Index_Pullback;

        private const int BaseScore = 60;
        private const int MinScore = 55;

        private const double MaxPullbackDepthAtr = 0.9;
        private const int MaxPullbackBars = 5;

        public EntryEvaluation Evaluate(EntryContext ctx)
        {
            var matrix = ctx?.SessionMatrixConfig ?? SessionMatrixDefaults.Neutral;
            if (!matrix.AllowPullback)
                return null;

            if (ctx == null || !ctx.IsReady || ctx.M5 == null || ctx.M5.Count < 10)
                return null;

            var p = IndexInstrumentMatrix.Get(ctx.Symbol);
            if (p == null)
                return null;

            var longEval = EvaluateSide(ctx, p, matrix, TradeDirection.Long);
            var shortEval = EvaluateSide(ctx, p, matrix, TradeDirection.Short);

            bool longValid = longEval != null && longEval.IsValid;
            bool shortValid = shortEval != null && shortEval.IsValid;

            if (!longValid && !shortValid)
                return null;

            if (longValid && shortValid)
                return longEval.Score >= shortEval.Score ? longEval : shortEval;

            return longValid ? longEval : shortEval;
        }

        private EntryEvaluation EvaluateSide(
            EntryContext ctx,
            dynamic p,
            SessionMatrixConfig matrix,
            TradeDirection dir)
        {
            // =============================
            // MATRIX DRIVEN THRESHOLDS
            // =============================
            double minAdxTrend = p.MinAdxTrend > 0 ? p.MinAdxTrend : 20;
            minAdxTrend = Math.Max(minAdxTrend, matrix.MinAdx);
            int maxBarsSinceImpulse = p.MaxBarsSinceImpulse_M5 > 0 ? p.MaxBarsSinceImpulse_M5 : 4;
            double minAtrPoints = p.MinAtrPoints > 0 ? p.MinAtrPoints : 0;

            double maxPullbackDepthAtr =
                p.PullbackStyle == IndexPullbackStyle.Shallow ? 0.7 :
                p.PullbackStyle == IndexPullbackStyle.Structure ? 1.0 :
                MaxPullbackDepthAtr;

            int maxPullbackBars =
                p.PullbackStyle == IndexPullbackStyle.Shallow ? 3 :
                p.PullbackStyle == IndexPullbackStyle.Structure ? 6 :
                MaxPullbackBars;

            int score = BaseScore;

            var bars = ctx.M5;
            int lastClosed = bars.Count - 2;

            bool hasImpulse =
                dir == TradeDirection.Long ? ctx.HasImpulseLong_M5 :
                dir == TradeDirection.Short ? ctx.HasImpulseShort_M5 :
                false;

            double pullbackDepthAtr =
                dir == TradeDirection.Long ? ctx.PullbackDepthRLong_M5 :
                dir == TradeDirection.Short ? ctx.PullbackDepthRShort_M5 :
                ctx.PullbackDepthAtr_M5;

            bool hasFlag =
                dir == TradeDirection.Long ? ctx.HasFlagLong_M5 :
                dir == TradeDirection.Short ? ctx.HasFlagShort_M5 :
                ctx.IsValidFlagStructure_M5;

            bool lastBarInDir =
                (dir == TradeDirection.Long && bars[lastClosed].Close > bars[lastClosed].Open) ||
                (dir == TradeDirection.Short && bars[lastClosed].Close < bars[lastClosed].Open);

            bool m1TriggerInDir = HasDirectionalM1Trigger(ctx, dir);

            // =====================================================
            // CHOP SOFT (matrix ADX)
            // =====================================================
            bool chopZone =
                ctx.Adx_M5 < minAdxTrend &&
                Math.Abs(ctx.PlusDI_M5 - ctx.MinusDI_M5) < 7 &&
                !ctx.IsAtrExpanding_M5;

            if (chopZone)
                score -= 6;

            // =====================================================
            // ATR sanity (matrix driven)
            // =====================================================
            if (minAtrPoints > 0 && ctx.AtrM5 < minAtrPoints)
                score -= 6;

            // =====================================================
            // TREND FATIGUE → SOFT
            // =====================================================
            bool adxExhausted =
                ctx.Adx_M5 > 45 &&
                ctx.AdxSlope_M5 <= 0;

            bool atrContracting =
                ctx.AtrSlope_M5 <= 0;

            bool diConverging =
                Math.Abs(ctx.PlusDI_M5 - ctx.MinusDI_M5) < 7;

            bool impulseStale =
                !hasImpulse ||
                ctx.BarsSinceImpulse_M5 > maxBarsSinceImpulse;

            int fatigueCount = 0;
            if (adxExhausted) fatigueCount++;
            if (atrContracting) fatigueCount++;
            if (diConverging) fatigueCount++;
            if (impulseStale) fatigueCount++;

            bool trendFatigue = fatigueCount >= 3;

            if (trendFatigue)
                score -= 12;

            // =====================================================
            // PULLBACK STRUCTURAL GATES
            // =====================================================

            if (ctx.IsAtrExpanding_M5 && pullbackDepthAtr > 0.6)
                score -= 6;

            if (pullbackDepthAtr > 0.5)
            {
                int compressionBars = Math.Max(0, Math.Min(ctx.PullbackBars_M5, 10));
                int compressionStart = Math.Max(0, lastClosed - compressionBars + 1);

                double compressionHigh = double.MinValue;
                double compressionLow = double.MaxValue;

                for (int i = compressionStart; i <= lastClosed; i++)
                {
                    compressionHigh = Math.Max(compressionHigh, bars[i].High);
                    compressionLow = Math.Min(compressionLow, bars[i].Low);
                }

                double compressionRange = compressionHigh - compressionLow;
                double atr = Math.Max(0, ctx.AtrM5);

                bool compressionDetected =
                    compressionBars >= 3 &&
                    compressionBars <= 10 &&
                    compressionRange <= atr * 0.6;

                if (!compressionDetected)
                {
                    ctx.Log?.Invoke($"[PB] dir={dir} rejected: deep pullback without compression");
                    return null;
                }

                TradeDirection impulseDirection =
                    ctx.ImpulseDirection != TradeDirection.None ? ctx.ImpulseDirection : dir;

                bool breakoutAligned =
                    (impulseDirection == TradeDirection.Long && bars[lastClosed].Close > compressionHigh) ||
                    (impulseDirection == TradeDirection.Short && bars[lastClosed].Close < compressionLow);

                if (!breakoutAligned)
                {
                    ctx.Log?.Invoke($"[PB] dir={dir} rejected: breakout against impulse");
                    return null;
                }

                ctx.Log?.Invoke($"[PB] dir={dir} DeepPullbackContinuation accepted");
            }

            if (pullbackDepthAtr <= 0 ||
                pullbackDepthAtr > maxPullbackDepthAtr)
                return null;

            if (ctx.PullbackBars_M5 > maxPullbackBars)
                return null;

            if (!ctx.HasReactionCandle_M5)
                return null;

            if (!lastBarInDir)
                score -= 10;

            double distFromEma =
                Math.Abs(ctx.M5.Last(1).Close - ctx.Ema21_M5);

            if (distFromEma > ctx.AtrM5 * 1.2)
                score -= 8;

            // =====================================================
            // CONTEXT BONUSES
            // =====================================================

            if (m1TriggerInDir)
                score += 10;

            if (ctx.MarketState?.IsTrend == true)
                score += 6;

            if (hasImpulse &&
                ctx.BarsSinceImpulse_M5 <= 2 &&
                pullbackDepthAtr < 0.6)
            {
                score += 8;
            }

            if (ctx.IsPullbackDecelerating_M5)
                score += 5;

            // =====================================================
            // VOL REGIME SOFT
            // =====================================================
            if (ctx.MarketState?.IsLowVol == true)
                score -= 12;

            // =====================================================
            // FLAG PRIORITY
            // =====================================================
            if (hasFlag &&
                m1TriggerInDir)
                score -= 12;

            // =====================================================
            // FINAL SCORE GATE
            // =====================================================
            score += (int)Math.Round(matrix.EntryScoreModifier);

            if (score < MinScore)
            {
                Console.WriteLine(
                    $"[IDX_PULLBACK][REJECT] LOW_SCORE({score}) | " +
                    $"dir={dir} | pbATR={pullbackDepthAtr:F2} | " +
                    $"pbBars={ctx.PullbackBars_M5} | fatigue={trendFatigue} | " +
                    $"ADX={ctx.Adx_M5:F1}"
                );
                return null;
            }

            Console.WriteLine(
                $"[IDX_PULLBACK][PASS] dir={dir} score={score} | " +
                $"pbATR={pullbackDepthAtr:F2} | pbBars={ctx.PullbackBars_M5} | " +
                $"fatigue={trendFatigue} | ADX={ctx.Adx_M5:F1}"
            );

            return new EntryEvaluation
            {
                Symbol = ctx.Symbol,
                Type = Type,
                Direction = dir,
                Score = score,
                IsValid = true,
                Reason =
                    $"IDX_PULLBACK_4.1 dir={dir} score={score} " +
                    $"pbATR={pullbackDepthAtr:F2} pbBars={ctx.PullbackBars_M5} fatigue={trendFatigue}"
            };
        }

        private static bool HasDirectionalM1Trigger(EntryContext ctx, TradeDirection dir)
        {
            if (ctx == null || ctx.M1 == null || ctx.M1.Count < 3)
                return false;

            int lastClosed = ctx.M1.Count - 2;
            int prevClosed = ctx.M1.Count - 3;

            var last = ctx.M1[lastClosed];
            var prev = ctx.M1[prevClosed];

            if (dir == TradeDirection.Long)
                return last.Close > last.Open && last.Close > prev.High;

            if (dir == TradeDirection.Short)
                return last.Close < last.Open && last.Close < prev.Low;

            return false;
        }
    }
}