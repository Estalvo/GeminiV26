using System;
using cAlgo.API;

namespace GeminiV26.Core.Risk.PositionSizing
{
    public static class CryptoPositionSizer
    {
        public static double Calculate(
            Robot bot,
            double riskPercent,
            double slPriceDistance,
            double lotCap,
            bool? isExecutionContext = null)
        {
            bool execCtx = isExecutionContext ?? false;

            if (riskPercent <= 0 || slPriceDistance <= 0 || lotCap <= 0)
                return 0;

            double balance = bot.Account.Balance;
            double riskAmount = balance * (riskPercent / 100.0);
            double rawUnits = riskAmount / slPriceDistance;
            double capUnits = lotCap * bot.Symbol.LotSize;
            double finalUnits = Math.Min(rawUnits, capUnits);
            string symbol = bot.SymbolName ?? "UNKNOWN";

            double normalized =
                bot.Symbol.NormalizeVolumeInUnits(
                    finalUnits,
                    RoundingMode.Down);

            if (execCtx)
            {
                GlobalLogger.Log(bot, $"[CRYPTO SIZE RAW] symbol={symbol} balance={balance:0.##} riskPercent={riskPercent:0.###} riskAmount={riskAmount:0.###} slDistance={slPriceDistance:0.########} rawUnits={rawUnits:0.###} capUnits={capUnits:0.###} finalUnits={finalUnits:0.###}");
                GlobalLogger.Log(bot, $"[CRYPTO SIZE NORMALIZED] symbol={symbol} normalizedUnits={normalized:0.########} minVolume={bot.Symbol.VolumeInUnitsMin:0.########} step={bot.Symbol.VolumeInUnitsStep:0.########} lotSize={bot.Symbol.LotSize:0.########}");
                bool capped = rawUnits > capUnits;
                double effectiveRisk = Math.Min(rawUnits, capUnits) * slPriceDistance;
                double riskDeviationPercent = riskAmount > 0
                    ? ((riskAmount - effectiveRisk) / riskAmount) * 100.0
                    : 0.0;
                GlobalLogger.Log(bot, $"[SCALING][LOTCAP] accountSize={balance:0.##} desiredVolume={rawUnits:0.####} actualVolume={finalUnits:0.####} capped={capped.ToString().ToLowerInvariant()} riskDeviationPercent={riskDeviationPercent:0.####}");
            }

            if (normalized < bot.Symbol.VolumeInUnitsMin)
            {
                if (execCtx)
                {
                    GlobalLogger.Log(bot, $"[CRYPTO SIZE ZERO] symbol={symbol} reason=below_min_after_normalization finalUnits={finalUnits:0.###} normalizedUnits={normalized:0.########} minVolume={bot.Symbol.VolumeInUnitsMin:0.########} step={bot.Symbol.VolumeInUnitsStep:0.########} riskPercent={riskPercent:0.###} slDistance={slPriceDistance:0.########}");
                }

                return 0;
            }

            return normalized;
        }
    }
}
