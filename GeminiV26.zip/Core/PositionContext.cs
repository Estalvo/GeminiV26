﻿// =========================================================
// GEMINI V26 – PositionContext
// Rulebook 1.0 – Single Source of Truth
//
// Szerepe:
// - Egyetlen, kanonikus state objektum egy trade teljes életciklusára
// - Entry → Risk → Exit → CSV → Analytics MIND innen dolgozik
//
// FONTOS ELVEK:
// - TradeCore / TradeRouter NEM számol confidence-et
// - EntryType → EntryScore-t ad
// - EntryLogic (instrument) → LogicConfidence-t ad
// - FinalConfidence ITT kerül kiszámításra és eltárolásra
//
// FinalConfidence felhasználása:
// - Risk sizing
// - TP / BE / Trailing policy
// - CSV tanulási adat
//
// FinalConfidence = kombinált minőségmutató,
// NEM belépési gate, NEM stratégiai döntés.
//
// Ez a fájl normatív, nem heurisztikus.
// =========================================================

using System;
using cAlgo.API;
using Gemini.Memory;
using GeminiV26.Core.Entry;
using GeminiV26.Core.Execution;

namespace GeminiV26.Core
{
    /// <summary>
    /// Trade lifecycle context.
    /// Phase 3.4-től:
    /// - Entry audit
    /// - RiskSizer → ExitManager policy bridge
    /// - Analytics
    /// </summary>
    public class PositionContext
    {
        // =========================
        // Identity / audit
        // =========================
        public long PositionId { get; set; }

        public string Symbol { get; set; } = string.Empty;
        public Robot Bot { get; set; }
        public Action<string> Log { get; set; }

        public string TempId { get; set; } = string.Empty;

        public string EntryAttemptId
        {
            get => TempId;
            set => TempId = value;
        }

        public string EntryType { get; set; } = string.Empty;

        public string EntryReason { get; set; } = string.Empty;

        public double RiskPriceDistance { get; set; }   // SL distance price-ban (entrykori)

        public TradeDirection FinalDirection { get; set; } = TradeDirection.None;

        public bool MissingDirLogged { get; set; }


        // =========================================================
        // CONFIDENCE PIPELINE (Rulebook 1.0)
        // =========================================================

        /// <summary>
        /// EntryType által számolt score (0–100).
        /// Setup minőségét írja le.
        /// </summary>
        public int EntryScore { get; set; }

        /// <summary>
        /// Instrument-specifikus EntryLogic által adott confidence (0–100).
        /// Bias / környezeti megerősítés.
        /// </summary>
        public int LogicConfidence { get; set; }

        /// <summary>
        /// Kombinált confidence érték.
        /// CSAK management és risk input.
        /// NEM belépési gate.
        /// </summary>
        public int FinalConfidence { get; private set; }

        public int AdjustedRiskConfidence { get; set; }

        private bool _isFinalConfidenceComputed;

        public DateTime EntryTime { get; set; }

        public DateTime LastUpdateUtc { get; set; } = DateTime.UtcNow;

        public double EntryPrice { get; set; }

        public double PipSize { get; set; }

        // =========================
        // TP / state flags
        // =========================
        public bool Tp1Hit { get; set; }

        public bool Tp1Executed { get; set; }

        public bool IsFullyClosing { get; set; }

        // =========================
        // Take profit prices (resolved at entry time)
        // =========================
        public double? Tp1Price { get; set; }

        /// <summary>
        /// TP1 partial close fraction (0..1).
        /// Used by executors to close a portion at TP1.
        /// </summary>
        public double Tp1CloseFraction { get; set; }

        public double Tp2Hit { get; set; }

        public bool Tp1DbgInit { get; set; }

        // =========================
        // Analytics volumes (units)
        // =========================
        public double EntryVolumeInUnits { get; set; }

        public double Tp1ClosedVolumeInUnits { get; set; }

        public double RemainingVolumeInUnits { get; set; }

        // =========================
        // ANALYTICS / EXIT STATE
        // =========================

        // Maximum elért pozitív R a trade élete során
        public double MaxFavorableR { get; set; }

        // Egységes kilépési ok (CSV / tanulás)
        public ExitReason ExitReason { get; set; }

        // =========================
        // Prices (resolved by executor)
        // =========================
        public double? Tp2Price { get; set; }

        public double BePrice { get; set; }

        // =========================
        // Modes
        // =========================
        public BeMode BeMode { get; set; }

        public TrailingMode TrailingMode { get; set; }

        // =========================
        // Execution quality policy hints
        // =========================
        public ExecutionQualityTier QualityTier { get; set; } = ExecutionQualityTier.Full;

        public bool ForceFastBE { get; set; }

        public bool ForceTightTrailing { get; set; }

        // =========================================================
        // RiskSizer → ExitManager bridge
        // (policy values, NOT prices)
        // =========================================================

        /// <summary>
        /// Initial SL ATR multiplier (instrument-specific).
        /// </summary>
        public double StopLossAtrMultiplier { get; set; }

        /// <summary>
        /// Initial stop-loss distance expressed in R.
        /// </summary>
        public double InitialStopLossR { get; set; }

        /// <summary>
        /// Take-profit structure (R-based).
        /// </summary>
        public double Tp1R { get; set; }
        public double Tp1Ratio { get; set; }

        public double Tp2R { get; set; }
        public double Tp2Ratio { get; set; }

        /// <summary>
        /// Maximum allowed lot size for this trade (policy).
        /// </summary>
        public double LotCap { get; set; }

        // =========================
        // Break-even policy (R-based)
        // =========================
        public double BeTriggerR { get; set; }

        public double BeOffsetR { get; set; }

        // =========================
        // Trailing policy (R / ATR-based)
        // =========================
        public double TrailingStartR { get; set; }

        public double TrailingAtrMultiplier { get; set; }

        public bool TrailingActivated { get; set; }

        public bool BeActivated { get; set; }

        // =========================================================
        // NEW: MFE / MAE / Viability state (NO LOGIC)
        // Phase 3.8+ prep: dead-trade prevention + reward routing
        //
        // CÉL:
        // - Trade közbeni életképesség mérés (MFE/MAE)
        // - Későbbi ExitManager/TVM döntések inputja
        // - Analytics / tanulási adat
        //
        // FONTOS:
        // - Ezek a mezők önmagukban NEM döntenek
        // - Csak state, amit az Executor/ExitManager frissít
        // =========================================================

        /// <summary>
        /// Best favorable price since entry.
        /// Long: max(high), Short: min(low).
        /// Default: 0 (ExitManager initkor érdemes entry árral indulni).
        /// </summary>
        public double BestFavorablePrice { get; set; }

        /// <summary>
        /// Worst adverse price since entry.
        /// Long: min(low), Short: max(high).
        /// Default: 0 (ExitManager initkor érdemes entry árral indulni).
        /// </summary>
        public double WorstAdversePrice { get; set; }

        /// <summary>
        /// Max Favorable Excursion expressed in R.
        /// (MFE_R = favorableMove / RiskPriceDistance).
        /// </summary>
        public double MfeR { get; set; }

        /// <summary>
        /// Max Adverse Excursion expressed in R.
        /// (MAE_R = adverseMove / RiskPriceDistance).
        /// </summary>
        public double MaeR { get; set; }

        /// <summary>
        /// EntryTime snapshot UTC-ban (külön viability window-hoz, ha kell).
        /// EntryTime már létezik; ez opcionális, de determinisztikus.
        /// </summary>
        public DateTime EntryTimeUtc { get; set; }

        /// <summary>
        /// M5 bar-számláló a trade életkorához (viability window).
        /// (ExitManager/Executor frissíti.)
        /// </summary>
        public int BarsSinceEntryM5 { get; set; }

        /// <summary>
        /// Viability ellenőrzés már lefutott-e (hogy ne ismételjük).
        /// </summary>
        public bool ViabilityChecked { get; set; }

        /// <summary>
        /// Dead trade jelölés (MFE alacsony + MAE nő → későbbi early-exit / büntetés alap).
        /// </summary>
        public bool IsDeadTrade { get; set; }

        /// <summary>
        /// Opcionális: miért lett dead trade (audit/analytics).
        /// </summary>
        public string DeadTradeReason { get; set; } = string.Empty;

        // =========================
        // MEMORY LIFECYCLE SNAPSHOT
        // =========================
        public MovePhase MovePhase { get; set; } = MovePhase.Unknown;

        public int MoveAge { get; set; }

        public int PullbackCount { get; set; }

        public MemoryTrustLevel ContextTrust { get; set; } = MemoryTrustLevel.Unknown;

        public bool RuntimeSymbolAvailable { get; set; } = true;

        // =========================================================
        // FinalConfidence calculation
        // =========================================================

        /// <summary>
        /// Computes FinalConfidence from EntryScore and LogicConfidence.
        ///
        /// Rulebook 1.0:
        /// - EntryScore = setup minőség (primer)
        /// - LogicConfidence = instrument bias (szekunder)
        ///
        /// Súlyozás:
        /// - EntryScore: 70%
        /// - LogicConfidence: 30%
        ///
        /// FinalConfidence:
        /// - NEM belépési gate
        /// - CSAK risk / management input
        /// - Determinisztikus, egyszer számolt érték
        /// </summary>
        public static int ComputeFinalConfidenceValue(int entryScore, int logicConfidence)
        {
            int entry = Math.Max(0, Math.Min(100, entryScore));
            int logic = Math.Max(0, Math.Min(100, logicConfidence));

            double combined =
                entry * 0.7 +
                logic * 0.3;

            return (int)Math.Round(combined, MidpointRounding.AwayFromZero);
        }

        public static int ClampRiskConfidence(int confidence)
        {
            return Math.Max(0, Math.Min(100, confidence));
        }

        public void ComputeFinalConfidence()
        {
            if (_isFinalConfidenceComputed)
                return;

            FinalConfidence = ComputeFinalConfidenceValue(EntryScore, LogicConfidence);
            if (AdjustedRiskConfidence <= 0)
            {
                // Failsafe fallback – MUST be visible
                AdjustedRiskConfidence = FinalConfidence;

                GlobalLogger.Log(Bot, "[CONF][ADJUSTED_FALLBACK] using FinalConfidence");
            }
            _isFinalConfidenceComputed = true;
        }

        // =========================================================
        // LEGACY COMPATIBILITY BRIDGE
        // Phase 3.7.x → 3.8 migration
        //
        // CÉL:
        // - Régi instrumentumok még ctx.Confidence-et használnak
        // - Új architektúrában FinalConfidence az egyetlen forrás
        //
        // MEGJEGYZÉS:
        // - Ez NEM új state
        // - NEM számol új értéket
        // - Csak alias a FinalConfidence-re
        // - Később 1 sor törlés
        // =========================================================
        [Obsolete("LEGACY – use FinalConfidence")]
        public int Confidence => FinalConfidence;

        // =========================================================
        // Phase 3.7.x → v2 PREP (SAFE, NO LOGIC)
        //
        // CÉL:
        // - Restart / rehydrate esetén állapotmegőrzés
        // - TP1 / Trailing duplikációk későbbi elkerülése
        //
        // FONTOS:
        // - Ezek az értékek JELENLEG nem vesznek részt döntésben
        // - Csak adat-előkészítés
        // =========================================================

        /// <summary>
        /// Entrykori teljes volume snapshot (units).
        /// Rehydrate után NEM szabad felülírni.
        /// </summary>
        public double InitialVolumeInUnits { get; set; }

        /// <summary>
        /// Rehydrate-ből származik-e a context.
        /// Csak meta / debug cél.
        /// </summary>
        public bool IsRehydrated { get; set; }

        /// <summary>
        /// Rehydrate meta timestamp UTC-ban.
        /// Restart audit / debug.
        /// </summary>
        public DateTime? RehydratedAtUtc { get; set; }

        /// <summary>
        /// Rehydrate eredet rövid leírása.
        /// Pl. LiveOpenPosition.
        /// </summary>
        public string RehydrateSource { get; set; } = string.Empty;

        /// <summary>
        /// Post-entry lifecycle initialization has been completed for this position.
        /// Guards one-time post-entry setup/logging in exit lifecycle registration.
        /// </summary>
        public bool PostEntryInitializationCompleted { get; set; }

        /// <summary>
        /// Rehydrate-specific recovery path completed.
        /// Once true, rehydrate resolver/recovery flow must not re-run on normal ticks.
        /// </summary>
        public bool RehydrateRecoveryCompleted { get; set; }

        /// <summary>
        /// Indicates whether the position still requires rehydrate recovery handling.
        /// </summary>
        public bool RequiresRehydrateRecovery => IsRehydrated && !RehydrateRecoveryCompleted;


        /// <summary>
        /// Utolsó ismert SL ár (pozíció az igazság).
        /// Trailing restore előkészítés.
        /// </summary>
        public double? LastStopLossPrice { get; set; }

        public double? InitialStopLossPrice { get; set; }


        // =========================
        // Post-TP1 management state
        // =========================
        public int PostTp1TrendScore { get; set; }

        public string PostTp1TrendState { get; set; } = string.Empty;

        public string PostTp1TrailingMode { get; set; } = string.Empty;

        public double Tp2ExtensionMultiplierApplied { get; set; } = 1.0;

        public double? LastExtendedTp2 { get; set; }

        public double? LastTrailingStopTarget { get; set; }

        public string LastTp2State { get; set; } = string.Empty;

        public double? LastTp2Value { get; set; }

        public bool RunnerActivated { get; set; }

        public string LastProfileState { get; set; } = string.Empty;

        public string LastProfileBucket { get; set; } = string.Empty;

        public bool? LastTtmAllowTp2Extension { get; set; }

        public double? LastTtmTp2Multiplier { get; set; }

        public bool TrailNoImprovementLogged { get; set; }

        public bool TrailNoStructureLogged { get; set; }

        public bool TrailLowProgressLogged { get; set; }

        public bool TrailAtrUnavailableLogged { get; set; }

        public bool TrailResolverFailedLogged { get; set; }

        public string LastTrailCheckFingerprint { get; set; } = string.Empty;

        public int TrailSteps { get; set; }

        public int LastStateTraceBarIndex { get; set; } = -1;

        public string LastStateTraceFingerprint { get; set; } = string.Empty;

        public bool MarketTrend { get; set; }

        public double Adx_M5 { get; set; }

        public int LastTvmEvalBar { get; set; } = -1;

        public int LastTvmLogBar { get; set; } = -1;
    }
}
