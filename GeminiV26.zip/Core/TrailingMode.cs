namespace GeminiV26.Core
{
    public enum TrailingMode
    {
        None,      // <-- EZ HI�NYZOTT
        Tight,
        Normal,
        Loose
    }
}
