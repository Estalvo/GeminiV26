namespace GeminiV26.Core
{
    public enum BeMode
    {
        None,
        AfterTp1,   // TP1 ut�n azonnal BE+buffer
        Delayed     // k�sleltetett BE (runner/extra felt�tel ut�n)
    }
}
