using cAlgo.API;
using GeminiV26.Core;
using GeminiV26.Core.Entry;

namespace GeminiV26.Instruments
{
    /// <summary>
    /// Phase 3.4+
    /// Instrument-specifikus PositionContext felt�lt�s.
    /// TradeCore NEM sz�mol, csak megh�vja.
    /// </summary>
    public interface IInstrumentContextBuilder
    {
        /// <summary>
        /// Felt�lti a PositionContext-et bel�p�si d�nt�s alapj�n.
        /// </summary>
        /// <param name="ctx">�res PositionContext</param>
        /// <param name="entry">kiv�lasztott entry (score, type, reason)</param>
        /// <param name="symbol">aktu�lis symbol</param>
        void Build(
            PositionContext ctx,
            EntryEvaluation entry
        );
    }
}
