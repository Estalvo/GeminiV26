﻿using GeminiV26.Core.Entry;
using GeminiV26.Core.Risk.Exposure;
using GeminiV26.Core.Risk.RiskProfiles;
using GeminiV26.Risk;

namespace GeminiV26.Instruments.NAS100
{
    /// <summary>
    /// NAS Instrument RiskSizer – Phase 3.7.x
    ///
    /// FILOZÓFIA:
    /// - Index-specifikus policy (NEM FX)
    /// - Score határozza meg a risket és az SL szélességét
    /// - SL ATR-alapú
    /// - TP1 = 1.0R (biztosítás)
    /// - TP2 ≈ 2.0R (reális index continuation)
    /// - Hard lot cap = 2.0
    ///
    /// A RiskSizer:
    /// - nem számol árat
    /// - nem nyit/zár
    /// - nem ismer account állapotot
    /// Csak policy-t ad.
    /// </summary>
    public class NasInstrumentRiskSizer : IInstrumentRiskSizer
    {
        // =====================================================
        // RISK % – score alapján
        // Cél: 1 jó trade = napi 100–200 USD
        // =====================================================
        public double GetRiskPercent(int finalConfidence)
        {
            return RiskProfileEngine.GetRiskPercent(finalConfidence);
        }

        // =====================================================
        // STOP LOSS – ATR multiplier
        // EntryType NEM játszik szerepet
        // =====================================================
        public double GetStopLossAtrMultiplier(int finalConfidence, EntryType entryType)
        {
            // NAS100 continuation model – adjunk levegőt a jó setupnak
            if (finalConfidence >= 85) return 2.2;
            if (finalConfidence >= 75) return 2.4;
            return 2.6;
        }

        // =====================================================
        // TAKE PROFIT – R struktúra
        // =====================================================
        public void GetTakeProfit(
            int finalConfidence,
            out double tp1R,
            out double tp1Ratio,
            out double tp2R,
            out double tp2Ratio)
        {
            // NAS100 – continuation-first model
            // Gyors biztosítás, de runner marad

            if (finalConfidence >= 85)
            {
                tp1R = 0.55;
                tp1Ratio = 0.50;
                tp2R = 2.2;
            }
            else if (finalConfidence >= 75)
            {
                tp1R = 0.50;
                tp1Ratio = 0.55;
                tp2R = 1.8;
            }
            else
            {
                tp1R = 0.40;
                tp1Ratio = 0.60;
                tp2R = 1.3;
            }

            tp2Ratio = 1.0 - tp1Ratio;
        }

        // =====================================================
        // LOT CAP – HARD LIMIT
        // =====================================================
        public double GetLotCap(int finalConfidence)
        {
            double riskPercent = RiskProfileEngine.GetRiskPercent(finalConfidence);
            return LotCapEngine.CalculateLotCap(
                LotCapEngine.ReferenceBalance,
                LotCapEngine.ReferenceSlDistance,
                riskPercent);
        }
    }
}
