﻿// =========================================================
// GEMINI V26 – NAS100 EntryLogic
// Phase 3.7.x – RULEBOOK 1.0 COMPLIANT
//
// SZEREP:
// - NAS100 instrument-specifikus belépési LOGIKA
// - Trend/bias meghatározás (Long / Short)
// - LogicConfidence (0–100) számítása
//
// FONTOS ALAPELVEK (Rulebook 1.0):
// - EntryLogic NEM belépési gate
// - EntryLogic NEM vétózhat
// - EntryLogic NEM dönt trade indításról
// - EntryLogic csak INFORMÁCIÓT szolgáltat
//
// TILOS:
// - hard threshold (confidence >= X) mint belépési feltétel
// - return false mint tiltás
// - impulse / session gate logika ide
//
// Gate-ek HELYE:
// - KIZÁRÓLAG TradeCore (SessionGate + ImpulseGate)
//
// KIMENET:
// - LastBias (TradeType.Buy / TradeType.Sell)
// - LastLogicConfidence (0–100)
// =========================================================

using cAlgo.API;
using cAlgo.API.Indicators;
using GeminiV26.Core.Entry;
using GeminiV26.Interfaces;
using System;

namespace GeminiV26.Instruments.NAS100
{
    public class NasEntryLogic : IEntryLogic
    {
        private readonly Robot _bot;

        // M5 = chart TF, M15 = HTF trend sanity (baseline)
        private readonly Bars _m5;
        private readonly Bars _m15;

        // Trend baseline (NAS)
        private readonly IndicatorDataSeries _ema50;
        private readonly IndicatorDataSeries _ema200;

        // HTF EMA (könnyű zajszűrés, nem gate!)
        private readonly IndicatorDataSeries _emaHtf;

        // Trend strength
        private readonly AverageDirectionalMovementIndexRating _adx;

        // Volatility scaling for confidence (NOT gate!)
        private readonly AverageTrueRange _atr;

        // ----- baseline params (Phase 3.7.x) -----
        private const int MinBars = 120;

        private const int EmaFast = 50;
        private const int EmaSlow = 200;

        private const int AdxPeriod = 14;
        private const double AdxTrend = 18.0;     // csak confidence pontozás
        private const double AdxStrong = 25.0;    // csak confidence pontozás

        private const int AtrPeriod = 14;

        // Output
        public int LastLogicConfidence { get; private set; }
        public TradeType LastBias { get; private set; }
        public TradeDirection LastDirection { get; private set; }

        public NasEntryLogic(Robot bot)
        {
            _bot = bot;

            _m5 = bot.Bars;
            _m15 = bot.MarketData.GetBars(TimeFrame.Minute15);

            // Indicators (M5)
            _ema50 = bot.Indicators.ExponentialMovingAverage(_m5.ClosePrices, EmaFast).Result;
            _ema200 = bot.Indicators.ExponentialMovingAverage(_m5.ClosePrices, EmaSlow).Result;

            // HTF trend sanity (M15 EMA21 baseline)
            _emaHtf = bot.Indicators.ExponentialMovingAverage(_m15.ClosePrices, 21).Result;

            // ADX / ATR
            _adx = bot.Indicators.AverageDirectionalMovementIndexRating(AdxPeriod);
            _atr = bot.Indicators.AverageTrueRange(AtrPeriod, MovingAverageType.Exponential);
        }

        /// <summary>
        /// EntryLogic értékelés.
        /// NEM tilt, NEM gate-el.
        /// Mindig beállítja: LastBias + LastLogicConfidence.
        /// </summary>
        public void Evaluate()
        {
            // Safe defaults (no signal state)
            LastBias = LastBias == 0 ? TradeType.Buy : LastBias;
            LastLogicConfidence = 0;
            LastDirection = TradeDirection.None;

            if (_m5 == null || _m5.Count < MinBars)
            {
                GlobalLogger.Log(_bot, $"[NAS LOGIC] bars<{MinBars} (count={_m5?.Count ?? 0}) -> default bias/conf");
                GlobalLogger.Log(_bot, $"[NAS LOGIC STATE] LastBias={LastBias} LastConf={LastLogicConfidence}");
                return;
            }

            int i = _m5.Count - 1;

            // --- trend direction (M5) ---
            double ema50 = _ema50[i];
            double ema200 = _ema200[i];

            // If equal / too close, keep default bias but reduce confidence slightly
            double emaDiff = ema50 - ema200;

            // --- strength/volatility ---
            double adx = _adx.ADX.LastValue;
            double atr = _atr.Result.LastValue;

            // --- HTF sanity (optional, informational only) ---
            double htfEma = _emaHtf.LastValue;
            double priceM15 = _m15.ClosePrices.LastValue;
            bool htfBull = priceM15 >= htfEma;

            // =========================
            // SIGNAL + BIAS
            // =========================
            NasEntrySignal signal = NasEntrySignal.None;
            TradeType computedBias = LastBias;

            double deadzone = atr * 0.1;

            if (Math.Abs(emaDiff) < deadzone)
            {
                signal = NasEntrySignal.None;
                // bias szándékosan NEM változik
            }
            else if (emaDiff > 0)
            {
                signal = NasEntrySignal.LongTrend;
                computedBias = TradeType.Buy;
            }
            else
            {
                signal = NasEntrySignal.ShortTrend;
                computedBias = TradeType.Sell;
            }

            // =========================
            // LOGIC CONFIDENCE (SOFT SCORING)
            // =========================
            int conf = 0;

            // Trend exists
            if (signal != NasEntrySignal.None)
                conf = 50;

            if (adx >= AdxTrend)    // 18
                conf += 5;

            if (adx >= AdxStrong)   // 25
                conf += 10;

            if (adx >= 35)
                conf += 15;

            // EMA separation relative to ATR (soft)
            // NAS-on ATR nagy, de a kapcsolat hasznos: ha a trend "szétnyílt", jobb a bias.
            double emaAbs = Math.Abs(emaDiff);
            if (atr > 0 && emaAbs > atr * 0.3)
                conf += 10;

            // HTF alignment bonus (soft)
            // Long esetén jó, ha HTF is bull; short esetén jó, ha HTF inkább bear.
            if (signal == NasEntrySignal.LongTrend && htfBull)
                conf += 5;
            else if (signal == NasEntrySignal.ShortTrend && !htfBull)
                conf += 5;

            // Clamp
            int computedConfidence = signal == NasEntrySignal.None
                ? 0
                : Math.Max(0, Math.Min(100, conf));

            LastBias = computedBias;
            LastLogicConfidence = computedConfidence;
            LastDirection = MapBiasToDirection(LastBias);

            if (LastLogicConfidence > 0 && LastDirection == TradeDirection.None)
                GlobalLogger.Log(_bot, "[DIR][LOGIC_ERROR] Direction missing in EntryLogic");

            // =========================
            // DEBUG (INFORMATÍV)
            // =========================
            GlobalLogger.Log(_bot, 
                $"[NAS LOGIC] signal={signal} bias={LastBias} logicConf={LastLogicConfidence} | " +
                $"ema50={ema50:F2} ema200={ema200:F2} diff={emaDiff:F2} | " +
                $"adx={adx:F1} atr={atr:F2} | " +
                $"htfBull={htfBull}"
            );
            GlobalLogger.Log(_bot, $"[NAS LOGIC STATE] LastBias={LastBias} LastConf={LastLogicConfidence}");
        }

        public void ApplyToEntryEvaluation(EntryEvaluation entry)
        {
            if (entry == null)
                return;

            entry.Direction = LastDirection;
            entry.LogicConfidence = LastLogicConfidence;

            if (entry.LogicConfidence > 0 && entry.Direction == TradeDirection.None)
                GlobalLogger.Log(_bot, "[DIR][LOGIC_ERROR] Direction missing in EntryLogic");
        }

        private static TradeDirection MapBiasToDirection(TradeType bias)
        {
            if (bias == TradeType.Buy)
                return TradeDirection.Long;

            if (bias == TradeType.Sell)
                return TradeDirection.Short;

            return TradeDirection.None;
        }

        // =========================================================
        // INTERNAL SIGNAL MODEL (NO EXTRA FILE)
        // =========================================================
        private enum NasEntrySignal
        {
            None = 0,
            LongTrend = 1,
            ShortTrend = 2
        }
    }
}
