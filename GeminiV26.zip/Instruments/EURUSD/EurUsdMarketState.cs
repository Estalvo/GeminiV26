namespace GeminiV26.Instruments.EURUSD
{
    public class EurUsdMarketState
    {
        public double AtrPips { get; set; }
        public double Adx { get; set; }

        // m�r volt
        public bool IsLowVol { get; set; }

        // �J � sz�ks�ges az executorhoz
        public bool IsTrend { get; set; }
    }

}
