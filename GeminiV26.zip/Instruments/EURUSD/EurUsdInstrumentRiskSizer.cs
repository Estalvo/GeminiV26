using GeminiV26.Core.Entry;
using GeminiV26.Core.Risk.Exposure;
using GeminiV26.Core.Risk.RiskProfiles;
using GeminiV26.Risk;
using System;

namespace GeminiV26.Instruments.EURUSD
{
    /// <summary>
    /// EURUSD money-risk policy – Phase 3.9 (Adaptive LotCap Upgrade)
    /// 
    /// Változás:
    /// - Dinamikusabb LotCap skálázás
    /// - Magas score esetén érezhető méretnövekedés
    /// - Borderline tradek továbbra is kontroll alatt
    /// 
    /// NINCS egyszerűsítés.
    /// NINCS logika törlés.
    /// </summary>
    public class EurUsdInstrumentRiskSizer : IInstrumentRiskSizer
    {
        // =========================
        // TUNING – változatlan
        // =========================
        private const double RiskMin = 0.20;
        private const double RiskLow = 0.25;
        private const double RiskMed = 0.35;
        private const double RiskHigh = 0.45;
        private const double RiskMax = 0.65;   // kis emelés 0.55 → 0.65

        private const double SlBase = 2.0;
        private const double SlWide = 2.4;
        private const double SlTight = 1.8;

        // =========================
        // RISK %
        // =========================
        public double GetRiskPercent(int finalConfidence)
        {
            return RiskProfileEngine.GetRiskPercent(finalConfidence);
        }

        // =========================
        // SL (ATR multiplier)
        // =========================
        public double GetStopLossAtrMultiplier(int score, EntryType entryType)
        {
            double n = NormalizeScore(score);

            // változatlan struktúra
            return 1.9 - n * 0.4;
        }

        // =========================
        // TP struktúra
        // =========================
        public void GetTakeProfit(
            int score,
            out double tp1R,
            out double tp1Ratio,
            out double tp2R,
            out double tp2Ratio)
        {
            double n = NormalizeScore(score);

            // FX: gyors biztosítás
            tp1R = 0.50;

            // FX: több partial zárás, főleg alacsonyabb score-nál
            // n=0  -> 0.72
            // n=1  -> 0.58
            tp1Ratio = 0.72 - n * 0.14;

            // FX: reális continuation cél, plafonnal (ne üldözzön 1.8R+)
            // n=0  -> 1.05
            // n=1  -> 1.55
            tp2R = 1.05 + n * 0.50;

            tp2Ratio = 1.0 - tp1Ratio;
        }

        // =========================
        // LOT CAP – UPGRADED
        // =========================
        public double GetLotCap(int finalConfidence)
        {
            double riskPercent = RiskProfileEngine.GetRiskPercent(finalConfidence);
            return LotCapEngine.CalculateLotCap(
                LotCapEngine.ReferenceBalance,
                LotCapEngine.ReferenceSlDistance,
                riskPercent);
        }

        // =========================
        // SCORE NORMALIZATION – változatlan
        // =========================
        private static double NormalizeScore(int score)
        {
            // FX reális tartomány: 55–90
            return Math.Clamp((score - 55) / 35.0, 0.0, 1.0);
        }
    }
}