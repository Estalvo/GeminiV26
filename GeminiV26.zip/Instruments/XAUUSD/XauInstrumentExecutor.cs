﻿// =========================================================
// GEMINI V26 – XAUUSD Instrument Executor
// Phase 3.7.x – RULEBOOK 1.0 COMPLIANT
//
// SZEREP:
// - XAUUSD instrument-specifikus végrehajtó
// - Mechanikus order execution (NEM dönt, NEM gate-el score alapján)
//
// ALAPELVEK:
// - Entry döntés: TradeRouter
// - Irány / confidence: XauEntryLogic
// - Környezet: XAU_MarketStateDetector
// - Risk / SL / TP policy: XauInstrumentRiskSizer
// - Trade menedzsment: XauExitManager
//
// FONTOS:
// - FinalConfidence = Single Source of Truth
// - MarketState tiltás XAU-specifikus, hard abort
// - Fix lot (Phase 3.7.x): statisztikai validálás miatt
// =========================================================

using System;
using System.Collections.Generic;
using cAlgo.API;
using GeminiV26.Core;
using GeminiV26.Core.Entry;
using GeminiV26.Core.Execution;
using GeminiV26.Core.Logging;
using GeminiV26.Core.Risk.PositionSizing;
using GeminiV26.Instruments.METAL;

namespace GeminiV26.Instruments.XAUUSD
{
    public class XauInstrumentExecutor
    {
        private readonly Robot _bot;
        private readonly XauInstrumentRiskSizer _riskSizer;
        private readonly XauExitManager _exitManager;
        private readonly Dictionary<long, PositionContext> _positionContexts;
        private readonly string _botLabel;

        // -----------------------------------------------------
        // MarketState detector (XAU-specifikus környezetfigyelés)
        // -----------------------------------------------------
        private readonly XauMarketStateDetector _marketStateDetector;

        public XauInstrumentExecutor(
            Robot bot,
            XauInstrumentRiskSizer riskSizer,
            XauExitManager exitManager,
            Dictionary<long, PositionContext> positionContexts,
            string botLabel)
        {
            _bot = bot;
            _riskSizer = riskSizer;
            _exitManager = exitManager;
            _positionContexts = positionContexts;
            _botLabel = botLabel;

            // MarketStateDetector inicializálása
            // NEM globális, csak XAU executor használja
            _marketStateDetector = new XauMarketStateDetector(bot);
        }

        // =========================================================
        // EXECUTION – XAUUSD
        // =========================================================
        public void ExecuteEntry(EntryEvaluation entry, EntryContext entryContext)
        {
            if (entry == null)
            {
                GlobalLogger.Log(_bot, "[DIR][EXEC_ABORT] Missing entry");
                return;
            }

            if (entryContext == null || entryContext.FinalDirection == TradeDirection.None)
            {
                GlobalLogger.Log(_bot, "[DIR][EXEC_ABORT] Missing FinalDirection");
                return;
            }

            TradeAuditLog.EnsureAttemptId(entryContext, _bot.Server.Time);
            DirectionGuard.Validate(entryContext, null, _bot.Print);


            GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[DIR][EXEC_FINAL] symbol={_bot.SymbolName} finalDir={entryContext.FinalDirection}", entryContext));

            if (entry.Direction != entryContext.FinalDirection)
            {
                GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[DIR][EXEC_MISMATCH] entryDir={entry.Direction} finalDir={entryContext.FinalDirection}", entryContext));
                // DO NOT TRUST entry.Direction
            }
            // =====================================================
            // 1️⃣ MARKET STATE CHECK (XAU-SPECIFIC HARD GATE)
            // -----------------------------------------------------
            // LowVol vagy HardRange esetén:
            // - NINCS score-módosítás
            // - NINCS router hack
            // - egyszerűen nem nyitunk
            // =====================================================
            if (_marketStateDetector == null)
            {
                GlobalLogger.Log(_bot, "[XAU EXEC] SKIP: MarketStateDetector NULL");
                return;
            }

            var ms = _marketStateDetector.Evaluate();

            // =========================
            // MARKET STATE – SOFT (XAU)
            // =========================
            int statePenalty = 0;

            if (ms.IsLowVol)
                statePenalty -= 15;     // XAU low vol veszélyes

            if (ms.IsHardRange)
                statePenalty -= 20;     // range-ben nem szeretjük

            if (ms.IsTrend)
                statePenalty += 5;      // pici bónusz

            // =====================================================
            // 2️⃣ TRADE TYPE (router döntése alapján)
            // =====================================================
            var tradeType =
                entryContext.FinalDirection == TradeDirection.Long
                    ? TradeType.Buy
                    : TradeType.Sell;

            int logicConfidence = PositionContext.ClampRiskConfidence(entryContext.LogicBiasConfidence);
            string logicConfidenceSource = "EntryContext.LogicBiasConfidence";

            if (logicConfidence <= 0 && entry.LogicConfidence > 0)
            {
                logicConfidence = PositionContext.ClampRiskConfidence(entry.LogicConfidence);
                logicConfidenceSource = "EntryEvaluation.LogicConfidence";
                GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[CONF][EXEC_FALLBACK] source={logicConfidenceSource} value={logicConfidence}", entryContext));
            }

            if (logicConfidence <= 0)
            {
                logicConfidence = 50;
                logicConfidenceSource = "NeutralDefault";
                GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[CONF][EXEC_FALLBACK] source={logicConfidenceSource} value={logicConfidence}", entryContext));
            }

            GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[CONF][EXEC_INPUT] entryScore={entry.Score} routedLogic={logicConfidence} source={logicConfidenceSource}", entryContext));

            // =====================================================
            // 3️⃣ POSITION CONTEXT – SSOT
            // -----------------------------------------------------
            // A context minden adatot tartalmaz,
            // amire az ExitManagernek szüksége lesz.
            // =====================================================
            var ctx = new PositionContext
            {
                Symbol = _bot.SymbolName,
                Bot = _bot,
                TempId = entryContext.TempId,
                EntryType = entry.Type.ToString(),
                EntryReason = entry.Reason,
                FinalDirection = entryContext.FinalDirection,

                EntryScore = entry.Score,

                LogicConfidence = logicConfidence,

                EntryTime = _bot.Server.Time,

                // Pre-exec becslés (fill után pontosítjuk)
                EntryPrice = tradeType == TradeType.Buy
                    ? _bot.Symbol.Ask
                    : _bot.Symbol.Bid,
                PipSize = entryContext.PipSize > 0 ? entryContext.PipSize : _bot.Symbol.PipSize,

                // TP1 policy (Phase 3.7.x – determinisztikus XAU)
                Tp1Hit = false,
                Tp1CloseFraction = 0.40,
                Tp1R = 0.25,

                MarketTrend = entryContext.FinalDirection != TradeDirection.None,
                Adx_M5 = entryContext.Adx_M5,

                InitialStopLossR = 1.0,
                BeMode = BeMode.AfterTp1
            };

            // -----------------------------------------------------
            // FinalConfidence összeállítása (Rulebook 1.0)
            // -----------------------------------------------------
            ctx.ComputeFinalConfidence();
            int adjustedRiskConfidence = PositionContext.ClampRiskConfidence(ctx.FinalConfidence + statePenalty);
            GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[CONF][FINAL] final={ctx.FinalConfidence} adjustedRisk={adjustedRiskConfidence} statePenalty={statePenalty}", entryContext));

                        GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId(TradeAuditLog.BuildEntrySnapshot(_bot, entryContext, entry), entryContext));
            GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId(TradeAuditLog.BuildDirectionSnapshot(entryContext, entry), entryContext));
            if (statePenalty != 0)
                GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[SOFT_PENALTY] value={statePenalty} riskFinal={adjustedRiskConfidence}", entryContext));

            // Trailing mód adjustedRiskConfidence alapján (FinalConfidence + statePenalty)
            ctx.TrailingMode =
                adjustedRiskConfidence >= 85 ? TrailingMode.Loose :
                adjustedRiskConfidence >= 75 ? TrailingMode.Normal :
                                             TrailingMode.Tight;

            // =====================================================
            // 4️⃣ SL / TP POLICY (adjustedRiskConfidence)
            // =====================================================
            double slPriceDist = _riskSizer.CalculateStopLossPriceDistance(
                _bot,
                adjustedRiskConfidence,
                entry.Type);

            if (slPriceDist <= 0)
            {
                GlobalLogger.Log(_bot, "[XAU EXEC] SL distance invalid → abort");
                return;
            }

            double tp2Price = _riskSizer.CalculateTp2PriceFromSlDistance(
                _bot,
                tradeType,
                adjustedRiskConfidence,
                slPriceDist);

            if (tp2Price <= 0)
            {
                GlobalLogger.Log(_bot, "[XAU EXEC] TP2 price invalid → abort");
                return;
            }

            // =====================================================
            // 5️⃣ TP / R VALUES (EURUSD MINTA SZERINT)
            // =====================================================
            _riskSizer.GetTakeProfit(
                adjustedRiskConfidence,
                out double tp1R,
                out double tp1Ratio,
                out double tp2R,
                out double tp2Ratio
            );

            // Context feltöltés – NINCS újraszámolás
            ctx.Tp1R = tp1R;
            ctx.Tp1Ratio = tp1Ratio;
            ctx.Tp2R = tp2R;
            ctx.Tp2Ratio = tp2Ratio;

            // =====================================================
            // 6️⃣ VOLUME POLICY – METAL POSITION SIZER (XAU)
            // =====================================================
            var quality = ExecutionQualityPolicy.Decide(entryContext, entry);
            ctx.QualityTier = quality.Tier;
            ctx.ForceFastBE = quality.ForceFastBE;
            ctx.ForceTightTrailing = quality.ForceTightTrailing;

            double riskPercent = _riskSizer.GetRiskPercent(adjustedRiskConfidence);
            riskPercent *= quality.RiskMultiplier;
            long volumeUnits = MetalPositionSizer.Calculate(
                _bot,
                riskPercent,
                slPriceDist,
                _riskSizer.GetLotCap(adjustedRiskConfidence)
            );

            if (volumeUnits <= 0)
            {
                GlobalLogger.Log(_bot, "[XAU EXEC] Volume invalid after MetalPositionSizer → abort");
                return;
            }
            // 🔎 DEBUG (EXECUTOR SZINT)
            GlobalLogger.Log(_bot, $"[XAU EXEC RISK] FC={ctx.FinalConfidence} slDist={slPriceDist:F2} units={volumeUnits} lot={(double)volumeUnits/_bot.Symbol.LotSize:F2}");
/*
            // =====================================================
            // 6 VOLUME POLICY – FIX LOT (Phase 3.7.x)
            // -----------------------------------------------------
            // Cél: tiszta statisztika TP1 / trailing validálásához.
            // Risk-alapú sizing később visszakapcsolható.
            // =====================================================
            double fixedLot = 0.10;
            long volumeUnits = (long)_bot.Symbol.QuantityToVolumeInUnits(fixedLot);

            if (volumeUnits <= 0)
            {
                GlobalLogger.Log(_bot, "[XAU EXEC] Volume invalid → abort");
                return;
            }
*/
            // =====================================================
            // 7 SL / TP → pips (pre-exec)
            // =====================================================
            double slPips = slPriceDist / _bot.Symbol.PipSize;
            double tp2Pips = Math.Abs(tp2Price - ctx.EntryPrice) / _bot.Symbol.PipSize;

            // =====================================================
            // 8 EXECUTE ORDER
            // =====================================================
            GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[ENTRY][EXEC][REQUEST] symbol={entry.Symbol ?? entryContext.Symbol ?? _bot.SymbolName} entryType={entry.Type} pipelineId={entryContext.TempId} side={tradeType} volumeUnits={volumeUnits} slPips={slPips:0.#####} tpPips={tp2Pips:0.#####}", entryContext));

            var result = _bot.ExecuteMarketOrder(
                tradeType,
                _bot.SymbolName,
                volumeUnits,
                _botLabel,
                slPips,
                tp2Pips,
                entryContext.TempId
            );

            if (!result.IsSuccessful || result.Position == null)
            {
                string errorCode = result?.Error.ToString() ?? "NA";
                string normalizedError = errorCode.ToUpperInvariant();
                string reason =
                    normalizedError.Contains("VOLUME") ? "volume_invalid" :
                    (normalizedError.Contains("SL") || normalizedError.Contains("TP") || normalizedError.Contains("STOP")) ? "sl_tp_invalid" :
                    normalizedError.Contains("MARKET") ? "market_closed" :
                    normalizedError.Contains("LIQUID") ? "no_liquidity" :
                    normalizedError.Contains("TIMEOUT") ? "timeout" :
                    (errorCode == "NA" || normalizedError.Contains("REJECT") || normalizedError.Contains("DENIED")) ? "broker_reject" :
                    "unknown";
                GlobalLogger.Log(_bot, TradeLogIdentity.WithTempId($"[ENTRY][EXEC][FAIL] symbol={entry.Symbol ?? entryContext.Symbol ?? _bot.SymbolName} entryType={entry.Type} pipelineId={entryContext.TempId} reason={reason} errorCode={errorCode}", entryContext));
                GlobalLogger.Log(_bot, "[XAU EXEC] Order execution failed");
                return;
            }

            GlobalLogger.Log(_bot, $"[TRADE LINK] tempId={entryContext.TempId} posId={result.Position.Id} symbol={result.Position.SymbolName}");
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds($"[EXEC] order placed volume={volumeUnits}", result.Position.Id, entryContext.TempId));

            // =====================================================
            // 9 CONTEXT FINALIZÁLÁS (FILL UTÁN)
            // =====================================================
            ctx.PositionId = result.Position.Id;
            ctx.EntryPrice = result.Position.EntryPrice;
            ctx.PipSize = entryContext.PipSize > 0 ? entryContext.PipSize : _bot.Symbol.PipSize;

            ctx.EntryVolumeInUnits = result.Position.VolumeInUnits;
            ctx.RemainingVolumeInUnits = result.Position.VolumeInUnits;
            ctx.InitialVolumeInUnits = ctx.EntryVolumeInUnits;

            // --- SL (kanonikus ár)
            double slPriceActual = result.Position.StopLoss ??
                (tradeType == TradeType.Buy
                    ? ctx.EntryPrice - slPriceDist
                    : ctx.EntryPrice + slPriceDist);

            double rDist = Math.Abs(ctx.EntryPrice - slPriceActual);
            ctx.InitialStopLossPrice = slPriceActual;
            ctx.RiskPriceDistance = Math.Abs(ctx.EntryPrice - slPriceActual);
            ctx.LastStopLossPrice = slPriceActual;
            _bot.Print($"[SL_SNAPSHOT] symbol={_bot.SymbolName} entry={ctx.EntryPrice} initialSL={slPriceActual}");

            // --- TP1 (fix R)
            ctx.Tp1Price = tradeType == TradeType.Buy
                ? ctx.EntryPrice + rDist * ctx.Tp1R
                : ctx.EntryPrice - rDist * ctx.Tp1R;

            // --- TP2
            ctx.Tp2Price = result.Position.TakeProfit.HasValue
                ? Convert.ToDouble(result.Position.TakeProfit.Value)
                : Convert.ToDouble(tp2Price);

            // =====================================================
            // 10 REGISTER CONTEXT
            // =====================================================
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(
                $"[ENTRY][EXEC][SUCCESS] symbol={ctx.Symbol ?? result.Position.SymbolName ?? _bot.SymbolName} entryType={ctx.EntryType} positionId={result.Position.Id} pipelineId={(ctx.PositionId > 0 ? ctx.PositionId.ToString() : (ctx.TempId ?? entryContext.TempId))}\n" +
                $"volumeUnits={ctx.EntryVolumeInUnits:0.##}\n" +
                $"entryPrice={ctx.EntryPrice:0.#####}\n" +
                $"sl={result.Position.StopLoss}\n" +
                $"tp={result.Position.TakeProfit ?? ctx.Tp2Price}", ctx, result.Position));
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(TradeAuditLog.BuildContextCreate(ctx), ctx, result.Position));
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(TradeAuditLog.BuildDirectionSnapshot(ctx), ctx, result.Position));
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(TradeAuditLog.BuildOpenSnapshot(ctx, result.Position.StopLoss, result.Position.TakeProfit ?? ctx.Tp2Price, ctx.EntryVolumeInUnits), ctx, result.Position));

            _positionContexts[ctx.PositionId] = ctx;
            ctx.AdjustedRiskConfidence = adjustedRiskConfidence;
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds($"[DIR][SET] posId={ctx.PositionId} finalDir={ctx.FinalDirection}", ctx));
            _exitManager.RegisterContext(ctx);

            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds($"[POSITION][OPEN] symbol={ctx.Symbol ?? _bot.SymbolName} entryType={ctx.EntryType} positionId={ctx.PositionId} pipelineId={(ctx.PositionId > 0 ? ctx.PositionId.ToString() : ctx.TempId)} entryPrice={ctx.EntryPrice}", ctx));

            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(

                $"[POSITION][CONTEXT] symbol={ctx.Symbol ?? _bot.SymbolName} positionId={ctx.PositionId} pipelineId={(ctx.PositionId > 0 ? ctx.PositionId.ToString() : ctx.TempId)} " +

                $"entryType={ctx.EntryType ?? "NA"} side={(result?.Position != null ? result.Position.TradeType.ToString() : "NA")} entryPrice={ctx.EntryPrice:0.#####} " +

                $"sl={(result?.Position?.StopLoss ?? 0):0.#####} tp1={(ctx.Tp1Price ?? 0):0.#####} tp2={(ctx.Tp2Price ?? 0):0.#####} " +

                $"riskPct={riskPercent:F2} confidence={ctx.FinalConfidence:F2} " +

                $"htfState={(entryContext != null ? entryContext.ActiveHtfDirection.ToString() : "NA")}", ctx));
            GlobalLogger.Log(_bot, TradeLogIdentity.WithPositionIds(
                $"[XAU EXEC] OPEN {tradeType} vol={ctx.EntryVolumeInUnits} " +
                $"FC={ctx.FinalConfidence} fill={ctx.EntryPrice:F2} " +
                $"SL={slPriceActual:F2} R={rDist:F2} " +
                $"TP1={ctx.Tp1Price:F2} TP2={ctx.Tp2Price:F2}", ctx));
        }
    }
}
