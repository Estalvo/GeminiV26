namespace GeminiV26.Instruments.XAUUSD
{
    public sealed class XauMarketState
    {
        // === �J MODELL (MEGMARAD) ===
        public double AtrPips { get; set; }
        public double Adx { get; set; }

        public bool IsLowVol { get; set; }
        public bool IsTrend { get; set; }

        public double RangeWidthAtr { get; set; }
        public bool IsHardRange { get; set; }

        public double WickRatioNow { get; set; }
        public bool IsChop { get; set; }

        // === KOMPATIBILIT�SI ALIASOK (TRADECORE MIATT) ===

        // r�gi ATR
        public double Atr => AtrPips;

        // r�gi range logika
        public bool IsRange => IsHardRange;
        public bool IsSoftRange => IsLowVol;
        public bool IsBreakout => IsTrend;
        public bool IsPostBreakout => false; // XAU-n�l nincs klasszikus postBO

        public double RangeWidth => RangeWidthAtr;

        // volume proxy (XAU-n�l nincs tick volume)
        public double VolumeNorm => WickRatioNow;
    }
}
