using cAlgo.API;
using GeminiV26.Core;

namespace GeminiV26.Interfaces
{
    public interface IExitManager
    {
        void OnBar(Position position);
        void OnTick();
        // Context bek�t�s TP1/BE/trailing �letre kelt�s�hez
        void RegisterContext(PositionContext ctx);
    }
}
